#include <cs50.h>
#include <stdio.h>

int main(void)
{
   int ht = -999;
   int i,j,t=2;
   
    do
   {
       printf("Height:");
       ht=get_int();
   }while(ht<0||ht>23);
   if(ht==0)
        printf("");
    else{
        for (i=0;i<ht;i++)
        {
            for(j=0;j<ht+1-t;j++)
            {
                printf(" ");
            
            }
            for(j=0;j<t;j++)
            {
                printf("#");
            
            }
        printf("\n");
        t+=1;
        } 
    }
   
   
}