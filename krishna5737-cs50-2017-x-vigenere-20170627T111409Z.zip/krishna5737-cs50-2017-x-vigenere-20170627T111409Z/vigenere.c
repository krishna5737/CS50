#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    long int i;
    char c;
    int j = 0 ;
    if(argc==2){
        string key=argv[1];
        for (i = 0; i < strlen(key); i++) {
            if (!isalpha(key[i])) {
                printf("Usage: ./caesar k\n");
                return 1;
            }
        }
        
        printf("plaintext: ");
        string s = get_string();
        printf("ciphertext: ");

        for(i=0;i<strlen(s);i++){
            j = j%(strlen(key));
            if(isalpha(s[i])){
                if(islower(s[i])){
                    if(islower(key[j]))
                        c = ((s[i]+key[j]-97-97)%26)+97;
                    else
                        c = ((s[i]+key[j]-65-97)%26)+97;
                    j++;
                }
                else
                if(isupper(s[i])){
                    if(islower(key[j]))
                        c = ((s[i]+key[j]-97-65)%26)+65;
                    else
                        c = ((s[i]+key[j]-65-65)%26)+65;
                    j++;
                }
                printf("%c",c);
            }
            else
                printf("%c",s[i]);
        }

    }
    else{
        printf("Usage: ./caesar k\n");
        return 1;
    }
    printf("\n");
        
}