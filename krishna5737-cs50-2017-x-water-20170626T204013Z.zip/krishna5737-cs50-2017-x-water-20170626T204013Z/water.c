#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int bottles=0;
    printf("Minutes: ");
    int minutes = get_int();
    bottles = minutes *12;
    printf("Bottles: %d\n",bottles);
}