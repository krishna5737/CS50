#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    long int i;
    char c;
    if(argc==2){
        int key=atoi(argv[1]);
        printf("plaintext: ");
        string s = get_string();
        printf("ciphertext: ");

        for(i=0;i<strlen(s);i++){
            if(isalpha(s[i])){
                if(islower(s[i])){
                    c = ((s[i]+key-97)%26)+97;
                }
                else
                if(isupper(s[i])){
                    //eprintf("bug%c\n",s[i]);
                    c = ((s[i]+key-65)%26)+65;
                }
                printf("%c",c);
            }
            else
                printf("%c",s[i]);
        }

    }
    else{
        printf("Usage: ./caesar k\n");
        return 1;
    }
    printf("\n");
}