/**
 * helpers.c
 *
 * Helper functions for Problem Set 3.
 */
 
#include <cs50.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    int i;
    int left = 0;
    int right = n-1;
    for(i=0;i<n;i++){
        int mid=(left+right)/2;
        if(values[mid] == value)
            return true;
        else
            if(values[mid]>value){
                n = mid ;
                right = mid -1;
                i-=1;
            }
            else{
                i = mid;
                left = mid+1;
            }
    }
    return false;
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement a sorting algorithm
    int i,j,temp=0;
    for(i=0;i<n-1;i++){
        for(j=i+1;j<n;j++){
            if(values[i]>values[j]){
                temp = values[i];
                values[i] = values[j];
                values[j] = temp;
            }
            
        }
            
    }
    return;
}