
#include <stdbool.h>
#include "dictionary.h"
#include <stdlib.h>

#define HSIZE 26
typedef struct node{
    char word[LENGTH +1];
    struct node* next;
}node;

node* hashtable[HSIZE];
unsigned int wc = 0;
bool loaded = false;

int it_hash(char* word_to_hashed){
    int i;
    int n = strlen(word_to_hashed);
    unsigned int hash =0;
    for (i = 0;  i < n; i++)
        hash = (hash<<2) ^ word_to_hashed[i];
    return hash % HSIZE;
     
}

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char *word)
{
    // TODO
    int i;
    int len = strlen(word);
    char image[len + 1];
    
    for(i = 0;i<len;i++){
        image[i]  = tolower(word[i]);
    }
    
    image[len] = '\0';
    
    int h = it_hash(image);
    node* temp = hashtable[h];
    
    while(temp != NULL){
        if(strcmp(temp->word , image) == 0)
            return true;
        else
            temp = temp->next;
    }       
    return false;
}

/**
 * Loads dictionary into memory. Returns true if successful else false.
 */
bool load(const char *dictionary){
    int i;
    for(i = 0 ; i < HSIZE; i++)
        hashtable[i] = NULL;
    // TODO
    FILE* fp = fopen(dictionary, "r");
    if(fp == NULL)
        return false;
        
    while(true){
        node* new_node = malloc(sizeof(node));
        if(new_node == NULL)
            return false;
    
        fscanf(fp, "%s", new_node->word);
        new_node->next = NULL;
        
        if (feof(fp)){
            free(new_node);
            break;
        }

        wc++;
        
        int h = it_hash(new_node->word);
        node* head = hashtable[h];
    
        if (head == NULL)
            hashtable[h] = new_node;
        else{
            new_node->next = hashtable[h];
            hashtable[h] = new_node;
        }
    }

    fclose(fp);
    loaded = true;
    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void){
    if (loaded)
        return wc;
    else
        return 0;
}

/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void){  
    int i;
    for (i = 0; i < HSIZE; i++){
        node* temp = hashtable[i];
        while (temp != NULL){    
            node* temp1 = temp;
            temp = temp->next;
            free(temp1);
        }
    }
    loaded = false;
    return true;
}