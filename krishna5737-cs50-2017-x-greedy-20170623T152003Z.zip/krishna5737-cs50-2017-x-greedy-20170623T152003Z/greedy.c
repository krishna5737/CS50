#include <cs50.h>
#include <stdio.h>

int main(void)
{
   float mone = 0;
   int money=0;
   printf("O hai!");
   do {
    printf("How much change is owed?\n");
    mone=get_float();
       
   }while(mone<0);
   
   money = mone *100;
   int coins=0;
   int new_coins = 0;
   coins=money/25;
   money = money  - (coins *25);

   new_coins = money/10;
   coins += new_coins;
   money = money  - (new_coins *10);

   new_coins = money/5;
   coins += new_coins;
   money = money  - (new_coins *5);
   
   coins += money;

    printf("%d\n",coins);
}